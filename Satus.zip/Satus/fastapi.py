from fastapi import FastAPI
from fastapi.middleware.wsgi import WSGIMiddleware
from flask import Flask, escape, request
from .satusapp.models import User, UserProfile

flask_app = Flask(__name__)


@flask_app.route("/")
def flask_main():
    name = request.args.get("name", "World")
    return f"Hello, {escape(name)} from Flask!"


app = FastAPI()


@app.get("/v2/users/")
def read_main():
    return {"All users": f"{User.objects.all()}"}


@app.get("/v2/user_profiles")
def read_main():
    return {"All profiles": f"{UserProfile.objects.all()}"}


app.mount("/v1", WSGIMiddleware(flask_app))
